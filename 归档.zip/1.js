console.log("xxxxx");
var GB2312UnicodeConverter = {
            ToUnicode: function (str) {
                return escape(str).toLocaleLowerCase().replace(/%u/gi, '\\u');
            }
            , ToGB2312: function (str) {
                return unescape(str.replace(/\\u/gi, '%u'));
            }
        };
 
        var str = '上海', unicode;
        console.log(str + '<br/>');
        unicode = GB2312UnicodeConverter.ToUnicode(str);
        console.log('汉字转换为Unicode代码：' + unicode + '<br/><br/>');
        console.log('Unicode代码转换为汉字：' + GB2312UnicodeConverter.ToGB2312(unicode));
        function encode_utf8(s) {
  return unescape(encodeURIComponent(s));
}

function decode_utf8(s) {
  return decodeURIComponent(escape(s));
}
function Utf8ArrayToStr(array) {
    var out, i, len, c;
    var char2, char3;

    out = "";
    len = array.length;
    i = 0;
    while(i < len) {
    c = array[i++];
    switch(c >> 4)
    { 
      case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
        // 0xxxxxxx
        out += String.fromCharCode(c);
        break;
      case 12: case 13:
        // 110x xxxx   10xx xxxx
        char2 = array[i++];
        out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
        break;
      case 14:
        // 1110 xxxx  10xx xxxx  10xx xxxx
        char2 = array[i++];
        char3 = array[i++];
        out += String.fromCharCode(((c & 0x0F) << 12) |
                       ((char2 & 0x3F) << 6) |
                       ((char3 & 0x3F) << 0));
        break;
    }
    }

    return out;
}
var slisli = ["给大家讲一个笑话，不好笑不给过",
"娇喘地说，我好寂寞，我要，我要，人家要嘛！",
"在空间发：喜欢我就赶紧向我表白吧！",
"自爆内衣/裤颜色",
"男生自爆长度，女生自爆胸围",
"给大家说个重口味段子～不重不给过",
"由2号出惩罚题目",
"唱一首儿歌，不得少于3句",
"恭喜你直接通过！",
"选一个玩家猜拳，你赢，惩罚转移给TA；否则，由TA指定某个惩罚",
"说自己最丢人的事",
"在空间发：今天才知道，原来我是同性恋",
"说出一个你目前喜欢的人是谁、干嘛的",
"坦白回答:你的初吻是几岁在什么地方被什么人夺去的?",
"喜欢一起游戏的哪位异性（一定要选），说出你的理由",
"娇喘的说：亚美蝶！亚美蝶！亚美蝶！",
"坦白回答：你想有gf/bf吗？什么样的?",
"对不起，你是今日最衰：执行惩罚1和惩罚6",
"坦白回答:你的初夜是几岁在什么地方被什么人夺去的?",
"模仿狗叫，至少叫3声",
"对一起游戏的一名异性深情告白30秒，不够深情不给过",
"大叫三声：我是屌丝",
"向左数第一个异性，跪地求婚状：如果我不向你求婚，我会后悔一辈子，因为你是我的惟一。",
"选一个男生 一边捶他的胸一边说： 你好讨厌哦。",
"与左数第一个异性正面对着十指交扣，深情对视，并朗诵骆《鹅》",
"恭喜你！你可以选择一名代你进行指定惩罚",
"跪着唱征服",
"如果时间能倒流你希望回到哪一时间，为什么？",
"自己一个人的时候流过泪吗？原因是？",
"如果看到自己最爱的人熟睡在你面前你会做什么？",
"情人节最想收到什么礼物？",
"请客/发个红包"]
function getPass(len)
{
	var tmpCh = "";
	for(var i = 0; i < len; i++)
	{
		var index = Math.floor(Math.random() * slisli.length);
		tmpCh += "惩罚" + (i + 1) + "：" + slisli[index] + "\r\n"
	}
	return tmpCh;
}
console.log(getPass(6))

/*
var crypto = require('crypto');
var http = require('http');
http.createServer(function(request,response)
	{
		var content = 'password'
		var md5 = crypto.createHash('md5');
		md5.update(content);
		var d = md5.digest('hex'); 
		console.log("有人访问" + request.url + "token:"+d);
		response.end('hello world');
	}
	).listen(3456);
// HEAD
console.log("xxxxx");
// c433d833b575a395cc0feaa18be80bf784c9bf36
// update express
console.log('server start at 888');*/
/*
2015-12-31T10:27:14.963035Z 1 [Note] A temporary password is generated for root@localhost: clZlyfp;W3qY
*/